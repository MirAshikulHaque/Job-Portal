<?php
$data=array();
require("db_rw.php");
//loadFromMySQL("select * from photo where name='".$_GET["uname"]."'");
loadFromMySQL("select * from photo");

foreach($data as $v){
	echo "<p>";
	echo $v["name"];
	echo ":";
	
	if(file_exists($v["purl"]))
		echo "<img alt='not found' src='".$v["purl"]."' width='100px' height='40px'/>";
	else
		echo "Image missing";
	echo "</p>";
}
//print_r($data);
?>