<pre>
<?php
require("db_rw.php");
//print_r($GLOBALS);
$tmp=$_FILES['fileToUpload']['tmp_name'];
$name=$_FILES['fileToUpload']['name'];
//echo time();
$ext=getExt($name);
$target="uploads/".time().".".$ext;

if($ext!="jpg"){
	echo "Invalid file type";
}
else if(file_exists($target)){
	echo "File already exists";
}
else{
	$t= move_uploaded_file($tmp,$target);
	$sql="insert into pic values(null,'".$_POST["uName"]."','".$target."')";
	echo $sql;
	$u=updateSQL($sql);
	echo "File uploaded:".$target;
}
?>
</pre>