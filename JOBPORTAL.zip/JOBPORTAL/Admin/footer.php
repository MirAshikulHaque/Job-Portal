   <!-- Footer -->
    <div id="footer">
       
        <hr class="noscreen" />
        
        <p class="style1" id="createdby">
          <!-- DON´T REMOVE, PLEASE! -->
        </p>
        <p id="copyright">&copy; job_portal123.com</p>
  </div> <!-- /footer -->