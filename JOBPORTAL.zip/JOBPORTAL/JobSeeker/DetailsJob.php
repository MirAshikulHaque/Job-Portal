
 

 <?php

 $con = mysqli_connect("localhost","root","","job");
 $result = mysqli_query($con,"select * from job_master where JobId = '".$_REQUEST["JobID"]."'") or die(mysqli_error($con));

 echo "<table class='table table-bordered'>";
            
            echo "<tr>";
            
            echo "<th>"; echo "Job Title"; echo "</th>";
            echo "<th>"; echo "Company Name"; echo "</th>";
            echo "<th>"; echo "Vacancy"; echo "</th>";
            echo "<th>"; echo "Qualification"; echo "</th>";
            echo "<th>"; echo "Description"; echo "</th>";

while($row = mysqli_fetch_assoc($result))
{
      $jt = $row["JobTitle"]." ";
      $cn =$row["CompanyName"]." ";
      $vc=$row["Vacancy"]." ";
      $qul =$row["MinQualification"]." ";
      $des = $row["Description"]."<br/>";
    
    
    ?>
    
    <tr>
        <td>
            <?php
                    
                  echo  $jt; 
                
                   ?>
            
        </td>
        
        <td>
            <?php
                    
                  echo  $cn; 
                
                   ?>
            
        </td>
        <td>
            <?php
                    
                  echo  $vc; 
                
                   ?>
            
        </td>
        <td>
            <?php
                    
                  echo  $qul; 
                
                   ?>
            
        </td>
        <td>
            <?php
                    
                  echo  $des; 
                
                   ?>
            
        </td>
       
        
    </tr>
    
    <?php
     
     
}
echo "</table>";

?>