<!-- Main menu (tabs) -->
     <div id="tabs" class="noprint">

            <h3 class="noscreen">Navigation</h3>
            <ul class="box">
                <li><a href="index.php">Home<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="Profile.php">Profile<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="Education.php">Education<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="SearchJob.php">Search Job<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="Walkin.php">Walkin Interview<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="Feedback.php">Feedback<span class="tab-l"></span><span class="tab-r"></span></a></li>
                <li><a href="Logout.php">Logout<span class="tab-l"></span><span class="tab-r"></span></a></li>
            </ul>

        <hr class="noscreen" />
     </div> <!-- /tabs -->