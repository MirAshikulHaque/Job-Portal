

   <?php


$con = mysqli_connect("localhost","root","","job");
    


    $sq = "select * from job_master where JobTitle like '".$_REQUEST["q"]."%'";
      $result=mysqli_query($con,$sq)or die(mysqli_error($con));
    

   
   while($row = mysqli_fetch_assoc($result))
   {
           
            ?>
                <a href="DetailsJob.php?JobID=<?php echo $row["JobId"]; ?>">

        <?php
            
                
       
                echo $row["JobTitle"]."<br/>";
                //echo $row["MinQualification"]."</br>";
       
        ?>
       
       </a> 
       
       <?php
       echo "</div>";
       
                    echo "</div>";
       
          

         
       
       
   }
 

    
  
    
?>